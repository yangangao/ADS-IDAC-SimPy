# -*- coding: UTF-8 -*-
import numpy as np


'''
此部分用于存储公共资源
'''

# SHIPINFO = {'ship1lon':[], 'ship1lat':[], 'ship2lon':[], 'ship2lat':[]}
SHIPSTATUS = []
# river作为公共资源共享
RIVER = np.zeros((10000, 100))
